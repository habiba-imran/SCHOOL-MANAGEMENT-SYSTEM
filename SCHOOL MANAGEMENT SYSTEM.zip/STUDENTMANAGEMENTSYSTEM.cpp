#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>
using namespace std;

const int MAX_STUDENTS = 100;

struct Student {
    string firstName;
    string rollNumber;
    string department;
    string semester;
    string contactNumber;
}students[MAX_STUDENTS];


int totalStudents = 0;
void saveToFile() {
    ofstream file("students.txt");//ofstream for writing 
    for (int i = 0; i < totalStudents; ++i) {
        file << students[i].firstName << " " << students[i].rollNumber << " " << students[i].department << " "
            << students[i].semester << " " << students[i].contactNumber << "\n";
    }
    file.close();
}

void loadFromFile() {
    ifstream file("students.txt");//for reading
    if (file.is_open()) {
        while (file >> students[totalStudents].firstName >> students[totalStudents].rollNumber >> students[totalStudents].department >>
            students[totalStudents].semester >> students[totalStudents].contactNumber) {
            totalStudents++;
        }
        file.close();
    }
}


void enter() {
    int choice;
    cout << "Enter number of students: ";
    cin >> choice;

    for (int i = 0; i < choice; ++i)
    {

        cout << "\nENTER DATA OF STUDENT " << totalStudents + 1 << ":\n";
        cout << "First Name: ";
        cin >> students[totalStudents].firstName;
        cout << "Roll Number: ";
        cin >> students[totalStudents].rollNumber;
        cout << "Department: ";
        cin >> students[totalStudents].department;
        cout << "Semester: ";
        cin >> students[totalStudents].semester;
        cout << "Contact Number: ";
        cin >> students[totalStudents].contactNumber;
        cout << endl;
        totalStudents++;
    }
    saveToFile();
}

void search() {
    string roll_num;
    cout << "Enter roll number of student to search his data: ";
    cin >> roll_num;

    for (int i = 0; i < totalStudents; ++i) {
        if (students[i].rollNumber == roll_num) {
            cout << "\nDATA OF STUDENT:\n";
            cout << "First Name: " << students[i].firstName << "\n";
            cout << "Roll Number: " << students[i].rollNumber << "\n";
            cout << "Department: " << students[i].department << "\n";
            cout << "Semester: " << students[i].semester << "\n";
            cout << "Contact Number: " << students[i].contactNumber << "\n\n";
            return;
        }
    }
    cout << "Student with roll number " << roll_num << " not found.\n";
}

void update() {
    string roll_num;
    cout << "Enter roll number of student to update his data: ";
    cin >> roll_num;

    for (int i = 0; i < totalStudents; ++i) {
        if (students[i].rollNumber == roll_num) {
            cout << "\nPREVIOUS DATA:\n";
            cout << "First Name: " << students[i].firstName << "\n";
            cout << "Roll Number: " << students[i].rollNumber << "\n";
            cout << "Department: " << students[i].department << "\n";
            cout << "Semester: " << students[i].semester << "\n";
            cout << "Contact Number: " << students[i].contactNumber << "\n\n";

            cout << "ENTER NEW DATA:\n";
            cout << "First Name: ";
            cin >> students[i].firstName;
            cout << "Roll Number: ";
            cin >> students[i].rollNumber;
            cout << "Department: ";
            cin >> students[i].department;
            cout << "Semester: ";
            cin >> students[i].semester;
            cout << "Contact Number: ";
            cin >> students[i].contactNumber;
            cout << endl;
            saveToFile();
            return;
        }
    }
    cout << "Student with roll number " << roll_num << " not found.\n";
}

void delete_record() {
    int choice;
    cout << "Press 1 to delete all records, 2 to delete by roll number: ";
    cin >> choice;

    if (choice == 1) {
        totalStudents = 0;
        cout << "ALL RECORDS DELETED!!!\n";
    }
    else if (choice == 2) {
        string roll_num;
        cout << "Enter roll number of student to delete: ";
        cin >> roll_num;

        for (int i = 0; i < totalStudents; ++i) {
            if (students[i].rollNumber == roll_num) {
                for (int j = i; j < totalStudents - 1; ++j) {
                    students[j] = students[j + 1];
                }
                totalStudents--;
                cout << "Record deleted.\n";
                saveToFile();
                return;
            }
        }
        cout << "Student with roll number " << roll_num << " not found.\n";
    }
    saveToFile();
}

void displayAll() {
    cout << "\nALL STUDENT RECORDS:\n";
    for (int i = 0; i < totalStudents; ++i) {
        cout << "DATA OF STUDENT " << i + 1 << ":\n";
        cout << "First Name: " << students[i].firstName << "\n";
        cout << "Roll Number: " << students[i].rollNumber << "\n";
        cout << "Department: " << students[i].department << "\n";
        cout << "Semester: " << students[i].semester << "\n";
        cout << "Contact Number: " << students[i].contactNumber << "\n\n";
    }
}


int main() {
    loadFromFile();

    cout << "|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\n";
    cout << "\n\t\t\t\t\tSCHOOL MANAGEMENT PROGRAM\n\n";
    cout << "|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\n";

    int value;
    while (true) {
        cout << endl << endl;

        cout << "Press 1 to enter data.\n";
        cout << "Press 2 to search data.\n";
        cout << "Press 3 to update data.\n";
        cout << "Press 4 to delete data.\n";
        cout << "Press 5 to display all data.\n";
        cout << "Press 6 to exit.\n";
        cout << "Enter your value: ";
        cin >> value;
        cout << endl;
        cout << "|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\n";
        cout << endl;
        switch (value)
        {

        case 1:
            enter();
            break;
        case 2:
            search();
            break;
        case 3:
            update();
            break;
        case 4:
            delete_record();
            break;
        case 5:
            displayAll();
            break;
        case 6:
            exit(0);
        default:
            cout << "Invalid value entered.\n";
            break;
        }
    }
}